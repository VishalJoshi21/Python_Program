decimal=int(input("Enter Decimal number :"));

print("Binary number :",bin(decimal));
print("Octal number :",oct(decimal));
print("Hexadecimal number :",hex(decimal));