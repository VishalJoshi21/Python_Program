cel=float(input("Enter Celsius :"));
fa=cel*9/5+32;
print("Fahrenheit ",fa);
fa=float(input("Enter Fahrenheit :"))
cel=(fa-32)*5/9;
print("Celsius ",cel);