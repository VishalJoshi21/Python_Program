num1=int(input("Enter number 1 :"));
num2=int(input("Enter number 2 :"));
num3=int(input("Enter number 3 :"));

maxx=max(num1,num2,num3);
minn=min(num1,num2,num3);

print("Maximum :",maxx);
print("Minimum :",minn);