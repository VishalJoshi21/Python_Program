import pylab

l1=["2015","2016","2017","2018","2019"]
l2=[5,4,12,10,15]
pylab.plot(l1,l2)
pylab.xlabel('Year')
pylab.ylabel('Profit In Percentage(%)')
pylab.title('Company Profit In Each Year')
pylab.show()
