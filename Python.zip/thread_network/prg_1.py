import threading

print(threading.currentThread().getName())
print(threading.current_thread())