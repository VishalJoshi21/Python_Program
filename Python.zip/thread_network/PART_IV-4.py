import socket

hostname='google.com'

hostname_ip= socket.gethostbyname(hostname)

print(hostname_ip)
